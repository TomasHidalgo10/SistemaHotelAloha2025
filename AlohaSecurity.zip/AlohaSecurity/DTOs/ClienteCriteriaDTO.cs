namespace DTOs
{
    public class ClienteCriteriaDTO
    {
        public string Texto { get; set; } = string.Empty;
    }
}