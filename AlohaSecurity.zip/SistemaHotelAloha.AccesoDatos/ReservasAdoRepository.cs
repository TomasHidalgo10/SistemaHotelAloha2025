﻿
using MySql.Data.MySqlClient;
using SistemaHotelAloha.AccesoDatos.Infra;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaHotelAloha.AccesoDatos
{
    public class ReservasAdoRepository
    {
        // DTO para la grilla
        public sealed record ReservaDto(
            int Id,
            int HabitacionId,
            string HabitacionLabel,
            DateTime Desde,
            DateTime Hasta,
            decimal PrecioTotal,
            string Estado
        );

        // --------------------------------------------------------------------
        //  HABITACIONES DISPONIBLES entre dos fechas
        //  Devuelve (Id, Label, PrecioBase)
        // --------------------------------------------------------------------
        public List<(int Id, string Label, decimal Precio)> GetHabitacionesDisponibles(DateTime desde, DateTime hasta)
        {
            using var cn = MySqlConnectionFactory.Create();
            using var cmd = new MySqlCommand(@"
SELECT  h.Id,
        CONCAT('Hab ', h.Numero, ' (', COALESCE(th.Nombre,'Standard'), ')') AS Label,
        h.PrecioBase
FROM Habitaciones h
LEFT JOIN tipo_habitacion th ON th.Id = h.TipoId
WHERE h.EstadoId IS NOT NULL
  AND NOT EXISTS
  (
    SELECT 1
    FROM Reservas r
    WHERE r.HabitacionId = h.Id
      AND r.Estado <> 'Cancelada'
      AND NOT (@Hasta <= r.FechaDesde OR @Desde >= r.FechaHasta)
  )
ORDER BY h.Numero;", cn);

            cmd.Parameters.AddWithValue("@Desde", desde);
            cmd.Parameters.AddWithValue("@Hasta", hasta);

            cn.Open();
            using var rd = cmd.ExecuteReader();
            var list = new List<(int, string, decimal)>();
            while (rd.Read())
            {
                var id = rd.GetInt32("Id");
                var label = rd["Label"]?.ToString() ?? $"Hab {id}";
                var precio = Convert.ToDecimal(rd["PrecioBase"]);
                list.Add((id, label, precio));
            }
            return list;
        }

        // --------------------------------------------------------------------
        //  CREAR reserva (valida solapamiento)
        //  Devuelve: Id nuevo o -100 si hay solapamiento
        // --------------------------------------------------------------------
        public int Crear(int usuarioId, int habitacionId, DateTime desde, DateTime hasta, decimal precioTotal)
        {
            using var cn = MySqlConnectionFactory.Create();
            cn.Open();

            // Chequeo de solapamiento en esa habitación
            using (var chk = new MySqlCommand(@"
SELECT COUNT(1)
FROM Reservas
WHERE HabitacionId=@H
  AND Estado<>'Cancelada'
  AND NOT (@Hasta <= FechaDesde OR @Desde >= FechaHasta);", cn))
            {
                chk.Parameters.AddWithValue("@H", habitacionId);
                chk.Parameters.AddWithValue("@Desde", desde);
                chk.Parameters.AddWithValue("@Hasta", hasta);

                if (Convert.ToInt32(chk.ExecuteScalar()) > 0)
                    return -100;
            }

            using var cmd = new MySqlCommand(@"
INSERT INTO Reservas (UsuarioId, HabitacionId, FechaDesde, FechaHasta, Estado, PrecioTotal, CreadaEn)
VALUES (@U, @H, @Desde, @Hasta, 'Confirmada', @Precio, UTC_TIMESTAMP());
SELECT LAST_INSERT_ID();", cn);

            cmd.Parameters.AddWithValue("@U", usuarioId);
            cmd.Parameters.AddWithValue("@H", habitacionId);
            cmd.Parameters.AddWithValue("@Desde", desde);
            cmd.Parameters.AddWithValue("@Hasta", hasta);
            cmd.Parameters.AddWithValue("@Precio", precioTotal);

            return Convert.ToInt32(cmd.ExecuteScalar());
        }

        // --------------------------------------------------------------------
        //  LISTAR reservas por usuario (para la grilla)
        // --------------------------------------------------------------------
        public List<ReservaDto> GetByUsuario(int usuarioId)
        {
            using var cn = MySqlConnectionFactory.Create();
            using var cmd = new MySqlCommand(@"
SELECT r.Id,
       r.HabitacionId,
       CONCAT('Hab ', h.Numero, ' (', COALESCE(th.Nombre,'Standard'), ')') AS HabLabel,
       r.FechaDesde,
       r.FechaHasta,
       r.PrecioTotal,
       r.Estado
FROM Reservas r
JOIN Habitaciones h   ON h.Id = r.HabitacionId
LEFT JOIN tipo_habitacion th ON th.Id = h.TipoId
WHERE r.UsuarioId=@U
ORDER BY r.Id DESC;", cn);

            cmd.Parameters.AddWithValue("@U", usuarioId);

            cn.Open();
            using var rd = cmd.ExecuteReader();
            var result = new List<ReservaDto>();
            while (rd.Read())
            {
                result.Add(new ReservaDto(
                    Id: rd.GetInt32("Id"),
                    HabitacionId: rd.GetInt32("HabitacionId"),
                    HabitacionLabel: rd["HabLabel"]?.ToString() ?? "",
                    Desde: Convert.ToDateTime(rd["FechaDesde"]),
                    Hasta: Convert.ToDateTime(rd["FechaHasta"]),
                    PrecioTotal: Convert.ToDecimal(rd["PrecioTotal"]),
                    Estado: rd["Estado"]?.ToString() ?? "Confirmada"
                ));
            }
            return result;
        }

        // --------------------------------------------------------------------
        //  CANCELAR reserva
        // --------------------------------------------------------------------
        public bool Cancelar(int id, int usuarioId)
        {
            using var cn = MySqlConnectionFactory.Create();
            using var cmd = new MySqlCommand(@"
UPDATE Reservas
SET Estado='Cancelada'
WHERE Id=@Id AND UsuarioId=@U;", cn);

            cmd.Parameters.AddWithValue("@Id", id);
            cmd.Parameters.AddWithValue("@U", usuarioId);

            cn.Open();
            return cmd.ExecuteNonQuery() > 0;
        }

        public int Actualizar(int id, int usuarioId, int habitacionId, DateTime desde, DateTime hasta, decimal precioTotal)
        {
            using var cn = MySqlConnectionFactory.Create();
            cn.Open();

            // Chequeo de solapamiento EXCLUYENDO la misma reserva (Id)
            using (var chk = new MySqlCommand(@"
SELECT COUNT(1)
FROM Reservas
WHERE HabitacionId=@H
  AND Estado<>'Cancelada'
  AND Id<>@Id
  AND NOT (@Hasta <= FechaDesde OR @Desde >= FechaHasta);", cn))
            {
                chk.Parameters.AddWithValue("@Id", id);
                chk.Parameters.AddWithValue("@H", habitacionId);
                chk.Parameters.AddWithValue("@Desde", desde);
                chk.Parameters.AddWithValue("@Hasta", hasta);

                if (Convert.ToInt32(chk.ExecuteScalar()) > 0)
                    return -100;
            }

            using var cmd = new MySqlCommand(@"
UPDATE Reservas
   SET HabitacionId=@H,
       FechaDesde=@Desde,
       FechaHasta=@Hasta,
       PrecioTotal=@Precio
 WHERE Id=@Id AND UsuarioId=@U;", cn);

            cmd.Parameters.AddWithValue("@Id", id);
            cmd.Parameters.AddWithValue("@U", usuarioId);
            cmd.Parameters.AddWithValue("@H", habitacionId);
            cmd.Parameters.AddWithValue("@Desde", desde);
            cmd.Parameters.AddWithValue("@Hasta", hasta);
            cmd.Parameters.AddWithValue("@Precio", precioTotal);

            return cmd.ExecuteNonQuery();
        }

        // --------------------------------------------------------------------
        //  LISTAR reservas con filtro opcional por estado (Confirmada/Cancelada)
        // --------------------------------------------------------------------
        public List<ReservaDto> GetByUsuario(int usuarioId, string? estado = null)
        {
            using var cn = MySqlConnectionFactory.Create();
            var sql = @"
SELECT r.Id,
       r.HabitacionId,
       CONCAT('Hab ', h.Numero, ' (', COALESCE(th.Nombre,'Standard'), ')') AS HabLabel,
       r.FechaDesde,
       r.FechaHasta,
       r.PrecioTotal,
       r.Estado
FROM Reservas r
JOIN Habitaciones h        ON h.Id = r.HabitacionId
LEFT JOIN tipo_habitacion th ON th.Id = h.TipoId
WHERE r.UsuarioId=@U";

            if (!string.IsNullOrWhiteSpace(estado))
                sql += " AND r.Estado=@E";

            sql += " ORDER BY r.Id DESC;";

            using var cmd = new MySqlCommand(sql, cn);
            cmd.Parameters.AddWithValue("@U", usuarioId);
            if (!string.IsNullOrWhiteSpace(estado))
                cmd.Parameters.AddWithValue("@E", estado);

            cn.Open();
            using var rd = cmd.ExecuteReader();
            var result = new List<ReservaDto>();
            while (rd.Read())
            {
                result.Add(new ReservaDto(
                    Id: rd.GetInt32("Id"),
                    HabitacionId: rd.GetInt32("HabitacionId"),
                    HabitacionLabel: rd["HabLabel"]?.ToString() ?? "",
                    Desde: Convert.ToDateTime(rd["FechaDesde"]),
                    Hasta: Convert.ToDateTime(rd["FechaHasta"]),
                    PrecioTotal: Convert.ToDecimal(rd["PrecioTotal"]),
                    Estado: rd["Estado"]?.ToString() ?? "Confirmada"
                ));
            }
            return result;
        }
    }
}