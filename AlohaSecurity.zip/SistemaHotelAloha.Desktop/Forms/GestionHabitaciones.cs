using SistemaHotelAloha.AccesoDatos;
using SistemaHotelAloha.Desktop.Models;
using SistemaHotelAloha.Desktop.Utils;
using System;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace SistemaHotelAloha.Desktop.Forms
{
    public partial class GestionHabitaciones : Form
    {
        // Repositorio y binding
        private readonly HabitacionAdoRepository _repo = new();
        private BindingList<Habitacion> _binding = null!;

        // NUEVOS: combos superpuestos a los TextBox
        //private ComboBox cmbTipo = null!;
        //private ComboBox cmbEstado = null!;

        public GestionHabitaciones()
        {
            InitializeComponent();
            dgvHabitaciones.AutoGenerateColumns = false;

            // por si no lo tenías conectado en el diseñador
            dgvHabitaciones.SelectionChanged -= dgvHabitaciones_SelectionChanged;
            dgvHabitaciones.SelectionChanged += dgvHabitaciones_SelectionChanged;
        }

        private void GestionHabitaciones_Load(object sender, EventArgs e)
        {
            // 1) Crear los combos en el lugar de los TextBox
            CrearCombosEnLugarDeTextBox();

            // 2) Bind de catálogos
            LookupService.Bind(cmbTipo, LookupService.Tipos());
            LookupService.Bind(cmbEstado, LookupService.Estados());

            // 3) Grilla y datos
            ConfigurarGrilla();
            CargarDatos();
        }

        /// <summary>
        /// Crea cmbTipo y cmbEstado exactamente donde estaban txtTipo y txtEstado,
        /// los agrega al formulario y oculta los TextBox para que no se pueda tipear.
        /// </summary>
        private void CrearCombosEnLugarDeTextBox()
        {
            // Asegura que existen los controles de texto (definidos en el Designer)
            // y coloca los ComboBox en su misma posición/tamaño.
            cmbTipo = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Left = txtTipo.Left,
                Top = txtTipo.Top,
                Width = txtTipo.Width,
                Height = txtTipo.Height,
                TabIndex = txtTipo.TabIndex
            };
            cmbEstado = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Left = txtEstado.Left,
                Top = txtEstado.Top,
                Width = txtEstado.Width,
                Height = txtEstado.Height,
                TabIndex = txtEstado.TabIndex
            };

            Controls.Add(cmbTipo);
            Controls.Add(cmbEstado);

            // Ocultamos los TextBox para impedir tipeo libre
            txtTipo.Visible = false;
            txtEstado.Visible = false;
        }

        private void ConfigurarGrilla()
        {
            dgvHabitaciones.Columns.Clear();

            // Número
            dgvHabitaciones.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Numero",
                HeaderText = "Número",
                Width = 100
            });

            // Tipo (combo)
            var colTipo = new DataGridViewComboBoxColumn
            {
                DataPropertyName = "TipoId",
                HeaderText = "Tipo",
                DataSource = LookupService.Tipos(),
                DisplayMember = "Nombre",
                ValueMember = "Id",
                FlatStyle = FlatStyle.Flat,
                Width = 150
            };
            dgvHabitaciones.Columns.Add(colTipo);

            // Estado (combo)
            var colEstado = new DataGridViewComboBoxColumn
            {
                DataPropertyName = "EstadoId",
                HeaderText = "Estado",
                DataSource = LookupService.Estados(),
                DisplayMember = "Nombre",
                ValueMember = "Id",
                FlatStyle = FlatStyle.Flat,
                Width = 150
            };
            dgvHabitaciones.Columns.Add(colEstado);

            // Precio
            dgvHabitaciones.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "PrecioNoche",
                HeaderText = "Precio/Noche",
                Width = 120,
                DefaultCellStyle = { Format = "N2" }
            });
        }

        private void CargarDatos()
        {
            var dt = _repo.GetAll(); // DataTable con Id, Numero, TipoId, EstadoId, PrecioBase, TipoNombre, EstadoNombre

            _binding = new BindingList<Habitacion>(
                dt.AsEnumerable().Select(r => new Habitacion
                {
                    Id = Convert.ToInt32(r["Id"]),
                    Numero = Convert.ToString(r["Numero"]) ?? string.Empty,
                    TipoId = Convert.ToInt32(r["TipoId"]),
                    EstadoId = Convert.ToInt32(r["EstadoId"]),
                    PrecioNoche = Convert.ToDecimal(r["PrecioBase"]),
                    TipoNombre = Convert.ToString(r["TipoNombre"]),
                    EstadoNombre = Convert.ToString(r["EstadoNombre"])
                }).ToList()
            );

            dgvHabitaciones.DataSource = _binding;
        }

        /// <summary>Lee controles y arma la entidad Habitacion (valida campos obligatorios).</summary>
        private Habitacion? GetFromInputs(bool includeId = false)
        {
            if (string.IsNullOrWhiteSpace(txtNumero.Text) ||
                cmbTipo.SelectedValue == null ||
                cmbEstado.SelectedValue == null ||
                string.IsNullOrWhiteSpace(txtPrecioNoche.Text))
            {
                MessageBox.Show("Completá Número, Tipo, Estado y Precio por noche.",
                    "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }

            if (!decimal.TryParse(txtPrecioNoche.Text, out var precio))
            {
                MessageBox.Show("Precio por noche inválido.",
                    "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }

            var h = new Habitacion
            {
                Numero = txtNumero.Text.Trim(),
                TipoId = (int)cmbTipo.SelectedValue!,
                EstadoId = (int)cmbEstado.SelectedValue!,
                PrecioNoche = precio
            };

            if (includeId && int.TryParse(txtId.Text, out var id))
                h.Id = id;

            return h;
        }

        private void dgvHabitaciones_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgvHabitaciones.CurrentRow?.DataBoundItem is Habitacion h)
            {
                txtId.Text = h.Id.ToString();
                txtNumero.Text = h.Numero;
                cmbTipo.SelectedValue = h.TipoId;
                cmbEstado.SelectedValue = h.EstadoId;
                txtPrecioNoche.Text = h.PrecioNoche.ToString("0.##");
            }
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            var h = GetFromInputs();
            if (h is null) return;

            // Nota: si Numero es numérico en BD, parseá; si es VARCHAR, enviá string
            var nuevoId = _repo.Create(
                int.Parse(h.Numero),
                h.TipoId,
                h.EstadoId,
                h.PrecioNoche
            );

            if (nuevoId > 0)
            {
                h.Id = nuevoId;
                _binding.Insert(0, h);
                Limpiar();
            }
            else
            {
                MessageBox.Show("No se pudo crear la habitación.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtId.Text, out var id))
            {
                MessageBox.Show("Seleccioná una habitación de la lista.",
                    "Atención", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var h = GetFromInputs(includeId: true);
            if (h is null) return;
            h.Id = id;

            var filas = _repo.Update(h.Id, int.Parse(h.Numero), h.TipoId, h.EstadoId, h.PrecioNoche);
            if (filas > 0)
                CargarDatos();
            else
                MessageBox.Show("No se pudo actualizar la habitación.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtId.Text, out var id))
            {
                MessageBox.Show("Seleccioná una habitación de la lista.",
                    "Atención", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("¿Eliminar la habitación seleccionada?",
                "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                var filas = _repo.Delete(id);
                if (filas > 0)
                {
                    CargarDatos();
                    Limpiar();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar la habitación.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Limpiar()
        {
            txtId.Clear();
            txtNumero.Clear();
            txtPrecioNoche.Clear();
            cmbTipo.SelectedIndex = -1;
            cmbEstado.SelectedIndex = -1;
            txtNumero.Focus();
        }
    }
}