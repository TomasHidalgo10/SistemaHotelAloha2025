﻿using SistemaHotelAloha.AccesoDatos;
using SistemaHotelAloha.Desktop.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaHotelAloha.Desktop.Forms
{
    public partial class GestionReservas : Form
    {
        // ---------- Controles (UI) ----------
        private Label lblDesde = null!;
        private Label lblHasta = null!;
        private DateTimePicker dtpDesde = null!;
        private DateTimePicker dtpHasta = null!;
        private Label lblHabitacion = null!;
        private ComboBox cmbHabitacion = null!;
        private Label lblPrecio = null!;
        private Label lblPrecioValor = null!;
        private Label lblEstadoReserva = null!;
        private ComboBox cmbEstadoReserva = null!;
        private Button btnCrear = null!;
        private Button btnModificar = null!;
        private Button btnCancelar = null!;
        private DataGridView dgvReservas = null!;

        // ---------- Lógica ----------
        private readonly ReservasAdoRepository _repo = new();
        private BindingList<ReservasAdoRepository.ReservaDto> _binding = null!;
        private const int UsuarioDemoId = 1; // reemplazar con el usuario logueado

        public GestionReservas()
        {
            InitializeComponent();
            Text = "Gestión de Reservas";
            Width = 950;
            Height = 580;
            StartPosition = FormStartPosition.CenterScreen;

            InicializarControles();
            ConfigurarGrilla();

            Load += GestionReservas_Load;
        }

        private void InicializarControles()
        {
            // ---------- Fechas ----------
            lblDesde = new Label { Text = "Desde:", Left = 20, Top = 20, AutoSize = true };
            dtpDesde = new DateTimePicker
            {
                Left = lblDesde.Right + 10,
                Top = lblDesde.Top - 3,
                Width = 130,
                Format = DateTimePickerFormat.Short
            };

            lblHasta = new Label { Text = "Hasta:", Left = dtpDesde.Right + 20, Top = 20, AutoSize = true };
            dtpHasta = new DateTimePicker
            {
                Left = lblHasta.Right + 10,
                Top = lblHasta.Top - 3,
                Width = 130,
                Format = DateTimePickerFormat.Short
            };

            // ---------- Habitación ----------
            lblHabitacion = new Label { Text = "Habitación:", Left = dtpHasta.Right + 25, Top = 20, AutoSize = true };
            cmbHabitacion = new ComboBox
            {
                Left = lblHabitacion.Right + 10,
                Top = lblHabitacion.Top - 3,
                Width = 200,
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            // ---------- Precio ----------
            lblPrecio = new Label { Text = "Precio:", Left = cmbHabitacion.Right + 25, Top = 20, AutoSize = true };
            lblPrecioValor = new Label
            {
                Text = "$0",
                Left = lblPrecio.Right + 10,
                Top = 20,
                AutoSize = true,
                Font = new System.Drawing.Font("Segoe UI", 9, System.Drawing.FontStyle.Bold)
            };

            // ---------- Estado ----------
            lblEstadoReserva = new Label { Text = "Estado:", Left = 20, Top = 60, AutoSize = true };
            cmbEstadoReserva = new ComboBox
            {
                Left = lblEstadoReserva.Right + 10,
                Top = lblEstadoReserva.Top - 3,
                Width = 180,
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            // ---------- Botones ----------
            btnCrear = new Button { Text = "Crear reserva", Left = 220, Top = 55, Width = 140, Height = 30 };
            btnModificar = new Button { Text = "Modificar seleccionada", Left = 370, Top = 55, Width = 170, Height = 30 };
            btnCancelar = new Button { Text = "Cancelar seleccionada", Left = 550, Top = 55, Width = 170, Height = 30 };

            btnCrear.Click += BtnCrear_Click;
            btnModificar.Click += BtnModificar_Click;
            btnCancelar.Click += BtnCancelar_Click;

            // ---------- Grilla ----------
            dgvReservas = new DataGridView
            {
                Left = 20,
                Top = 110,
                Width = 890,
                Height = 400,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AutoGenerateColumns = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            dgvReservas.SelectionChanged += DgvReservas_SelectionChanged;

            Controls.AddRange(new Control[]
            {
                lblDesde, dtpDesde, lblHasta, dtpHasta,
                lblHabitacion, cmbHabitacion, lblPrecio, lblPrecioValor,
                lblEstadoReserva, cmbEstadoReserva,
                btnCrear, btnModificar, btnCancelar,
                dgvReservas
            });
        }

        private void ConfigurarGrilla()
        {
            dgvReservas.Columns.Clear();

            dgvReservas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "HabitacionLabel",
                HeaderText = "Habitación",
                Width = 230
            });
            dgvReservas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Desde",
                HeaderText = "Desde",
                Width = 120,
                DefaultCellStyle = { Format = "d" }
            });
            dgvReservas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Hasta",
                HeaderText = "Hasta",
                Width = 120,
                DefaultCellStyle = { Format = "d" }
            });
            dgvReservas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "PrecioTotal",
                HeaderText = "Precio Total",
                Width = 130,
                DefaultCellStyle = { Format = "N0", Alignment = DataGridViewContentAlignment.MiddleRight }
            });
            dgvReservas.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Estado",
                HeaderText = "Estado",
                Width = 140
            });
        }

        private void GestionReservas_Load(object? sender, EventArgs e)
        {
            // 🔹 Catálogo de estados
            LookupService.Bind(cmbEstadoReserva, LookupService.EstadosReserva());
            cmbEstadoReserva.SelectedIndexChanged += (s, ev) => CargarDatos();

            // 🔹 Eventos de fechas y combos
            dtpDesde.ValueChanged += (s, ev) => ActualizarHabitacionesDisponibles();
            dtpHasta.ValueChanged += (s, ev) => ActualizarHabitacionesDisponibles();
            cmbHabitacion.SelectedIndexChanged += (s, ev) => MostrarPrecioSeleccionado();

            // 🔹 Fechas iniciales
            dtpDesde.Value = DateTime.Today;
            dtpHasta.Value = DateTime.Today.AddDays(1);

            ActualizarHabitacionesDisponibles();
            CargarDatos();
        }

        private void CargarDatos()
        {
            string? estado = null;
            if (cmbEstadoReserva.SelectedValue is int id && id > 0)
                estado = LookupService.EstadoReservaNombreById(id);

            _binding = new BindingList<ReservasAdoRepository.ReservaDto>(
                _repo.GetByUsuario(UsuarioDemoId, estado)
            );
            dgvReservas.DataSource = _binding;
        }

        // ---------- Habitaciones disponibles + precio ----------
        private void ActualizarHabitacionesDisponibles()
        {
            var desde = dtpDesde.Value.Date;
            var hasta = dtpHasta.Value.Date;
            if (hasta <= desde)
            {
                cmbHabitacion.DataSource = null;
                lblPrecioValor.Text = "$0";
                return;
            }

            var disponibles = _repo.GetHabitacionesDisponibles(desde, hasta);
            cmbHabitacion.DataSource = disponibles;
            cmbHabitacion.DisplayMember = "Item2";
            cmbHabitacion.ValueMember = "Item1";
            MostrarPrecioSeleccionado();
        }

        private void MostrarPrecioSeleccionado()
        {
            if (cmbHabitacion.SelectedItem is ValueTuple<int, string, decimal> sel)
                lblPrecioValor.Text = $"${sel.Item3:N0}";
            else
                lblPrecioValor.Text = "$0";
        }

        // ---------- Al seleccionar una fila ----------
        private void DgvReservas_SelectionChanged(object? sender, EventArgs e)
        {
            if (dgvReservas.CurrentRow?.DataBoundItem is not ReservasAdoRepository.ReservaDto r)
                return;

            dtpDesde.Value = r.Desde.Date;
            dtpHasta.Value = r.Hasta.Date;
            ActualizarHabitacionesDisponiblesManteniendo(r.HabitacionId);

            for (int i = 0; i < cmbHabitacion.Items.Count; i++)
            {
                if (cmbHabitacion.Items[i] is ValueTuple<int, string, decimal> tupla && tupla.Item1 == r.HabitacionId)
                {
                    cmbHabitacion.SelectedIndex = i;
                    lblPrecioValor.Text = $"${tupla.Item3:N0}";
                    break;
                }
            }
        }

        private void ActualizarHabitacionesDisponiblesManteniendo(int habitacionActualId)
        {
            var desde = dtpDesde.Value.Date;
            var hasta = dtpHasta.Value.Date;
            if (hasta <= desde)
            {
                cmbHabitacion.DataSource = null;
                lblPrecioValor.Text = "$0";
                return;
            }

            var disponibles = _repo.GetHabitacionesDisponibles(desde, hasta);
            bool contieneActual = disponibles.Exists(d => d.Id == habitacionActualId);

            if (!contieneActual && habitacionActualId > 0)
                disponibles.Insert(0, (habitacionActualId, "⚠ Habitación actual (ocupada)", 0m));

            cmbHabitacion.DataSource = disponibles;
            cmbHabitacion.DisplayMember = "Item2";
            cmbHabitacion.ValueMember = "Item1";
        }

        // ---------- Crear ----------
        private void BtnCrear_Click(object? sender, EventArgs e)
        {
            if (cmbHabitacion.SelectedItem is not ValueTuple<int, string, decimal> sel)
            {
                MessageBox.Show("Seleccioná una habitación disponible.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var desde = dtpDesde.Value.Date;
            var hasta = dtpHasta.Value.Date;
            if (hasta <= desde)
            {
                MessageBox.Show("El rango de fechas no es válido.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var precio = sel.Item3;
            var nuevoId = _repo.Crear(UsuarioDemoId, sel.Item1, desde, hasta, precio);

            if (nuevoId == -100)
            {
                MessageBox.Show("Esa habitación ya está reservada en ese rango.", "Conflicto",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                ActualizarHabitacionesDisponibles();
                return;
            }

            MessageBox.Show($"Reserva creada (ID {nuevoId}).", "Éxito",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarDatos();
            ActualizarHabitacionesDisponibles();
        }

        // ---------- Modificar ----------
        private void BtnModificar_Click(object? sender, EventArgs e)
        {
            if (dgvReservas.CurrentRow?.DataBoundItem is not ReservasAdoRepository.ReservaDto rSel)
            {
                MessageBox.Show("Seleccioná una reserva en la lista.", "Atención",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (cmbHabitacion.SelectedItem is not ValueTuple<int, string, decimal> sel)
            {
                MessageBox.Show("Seleccioná una habitación disponible.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var desde = dtpDesde.Value.Date;
            var hasta = dtpHasta.Value.Date;
            if (hasta <= desde)
            {
                MessageBox.Show("El rango de fechas no es válido.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var precio = sel.Item3;
            var filas = _repo.Actualizar(rSel.Id, UsuarioDemoId, sel.Item1, desde, hasta, precio);

            if (filas == -100)
            {
                MessageBox.Show("La habitación está ocupada en esas fechas.", "Conflicto",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (filas <= 0)
            {
                MessageBox.Show("No se pudo modificar la reserva.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show("Reserva modificada correctamente.", "Éxito",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarDatos();
            ActualizarHabitacionesDisponibles();
        }

        // ---------- Cancelar ----------
        private void BtnCancelar_Click(object? sender, EventArgs e)
        {
            if (dgvReservas.CurrentRow?.DataBoundItem is not ReservasAdoRepository.ReservaDto r)
            {
                MessageBox.Show("Seleccioná una reserva en la lista.", "Atención",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show($"¿Cancelar la reserva #{r.Id}?",
                "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            var ok = _repo.Cancelar(r.Id, UsuarioDemoId);
            if (!ok)
            {
                MessageBox.Show("No se pudo cancelar la reserva.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show("Reserva cancelada correctamente.", "Éxito",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarDatos();
            ActualizarHabitacionesDisponibles();
        }
    }
}