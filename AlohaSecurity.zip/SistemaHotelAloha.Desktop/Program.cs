﻿using SistemaHotelAloha.AccesoDatos.Infra;
using SistemaHotelAloha.Desktop.Forms;
using SistemaHotelAloha.Desktop.Utils;

namespace SistemaHotelAloha.Desktop
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            // 1) Inicializar/validar BD (opcional: si no tenés DatabaseBootstrapper, quitá este bloque)
            try
            {
                DatabaseBootstrapper.EnsureCreated();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Error inicializando la base de datos:\n\n{ex.Message}",
                    "ALOHA_DB",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
                return;
            }

            // 2) Inicializar la UI y abrir el Home una sola vez
            ApplicationConfiguration.Initialize();

            // Si tenés una caché/precarga de catálogos, podés llamarla aquí:
            // try { LookupCache.Initialize(); } catch { /* no bloquear el arranque */ }

            Application.Run(new Home()); // o new Forms.Home() si tu clase se llama así
        }
    }
}