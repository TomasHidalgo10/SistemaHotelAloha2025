using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SistemaHotelAloha.Web.Pages
{
    public class _ViewImportsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
